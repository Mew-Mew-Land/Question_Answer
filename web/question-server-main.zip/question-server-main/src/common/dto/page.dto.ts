import { PartialType } from '@nestjs/swagger';
import { PaginationDTO } from './pagination.dto';

export class PageDTO extends PaginationDTO {}
